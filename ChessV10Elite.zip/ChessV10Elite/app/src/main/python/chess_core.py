import os
import math
import json
import random
import cv2
import numpy as np
import chess
import chess.engine

PIECE_INFO = {
    chess.PAWN:   {"name": "TỐT",   "short": "P", "color": "#2ECC71"},
    chess.KNIGHT: {"name": "MÃ",    "short": "N", "color": "#E67E22"},
    chess.BISHOP: {"name": "TƯỢNG", "short": "B", "color": "#00BCD4"},
    chess.ROOK:   {"name": "XE",    "short": "R", "color": "#E74C3C"},
    chess.QUEEN:  {"name": "HẬU",   "short": "Q", "color": "#9B59B6"},
    chess.KING:   {"name": "VUA",   "short": "K", "color": "#F1C40F"},
}

STEALTH_PROFILES = {
    0: {"name": "🛡️ ULTRA STEALTH (~86%)", "max_cp_loss": 34, "target_acpl": 18.0, "temp": 16.0},
    1: {"name": "👑 GRANDMASTER (~92%)",   "max_cp_loss": 15, "target_acpl": 9.0,  "temp": 9.0},
    2: {"name": "⚡ GOD MODE (100% Top-1)", "max_cp_loss": 0,  "target_acpl": 0.0,  "temp": 1.0},
}


class AutoBoardDetector:
    @staticmethod
    def _score_checkerboard_candidate(gray_patch):
        resized = cv2.resize(gray_patch, (256, 256), interpolation=cv2.INTER_AREA)
        cell_size = 32
        even_lums, odd_lums = [], []
        for r in range(8):
            for c in range(8):
                y0, x0 = r * cell_size, c * cell_size
                bg_strip = resized[y0 + 3:y0 + 9, x0 + 7:x0 + 25]
                val = float(np.median(bg_strip))
                if (r + c) % 2 == 0:
                    even_lums.append(val)
                else:
                    odd_lums.append(val)
        med_even = float(np.median(even_lums))
        med_odd = float(np.median(odd_lums))
        contrast = med_even - med_odd
        if abs(contrast) < 12.0:
            return -1.0
        iqr_even = float(np.percentile(even_lums, 75) - np.percentile(even_lums, 25))
        iqr_odd = float(np.percentile(odd_lums, 75) - np.percentile(odd_lums, 25))
        if iqr_even > abs(contrast) * 0.85 and iqr_odd > abs(contrast) * 0.85:
            return -1.0
        gx = np.abs(cv2.Sobel(resized, cv2.CV_32F, 1, 0, ksize=3))
        gy = np.abs(cv2.Sobel(resized, cv2.CV_32F, 0, 1, ksize=3))
        col_proj = np.mean(gx, axis=0)
        row_proj = np.mean(gy, axis=1)
        grid_indices = [i * 32 for i in range(1, 8)]
        non_grid_indices = [i * 32 + 16 for i in range(8)]
        grid_energy = sum(
            np.max(col_proj[idx - 2:idx + 3]) + np.max(row_proj[idx - 2:idx + 3]) for idx in grid_indices
        ) / 14.0
        mid_energy = (np.mean(col_proj[non_grid_indices]) + np.mean(row_proj[non_grid_indices])) / 2.0 + 1.0
        grid_ratio = grid_energy / mid_energy
        if grid_ratio < 1.15:
            return -1.0
        polarity_bonus = 1.25 if contrast > 0 else 0.85
        return float(abs(contrast) * grid_ratio * polarity_bonus)

    @classmethod
    def auto_detect_board(cls, full_bgr):
        full_gray = cv2.cvtColor(full_bgr, cv2.COLOR_BGR2GRAY)
        h_scr, w_scr = full_gray.shape
        min_board_size = int(min(h_scr, w_scr) * 0.25)
        max_board_size = int(min(h_scr, w_scr) * 1.00)
        candidates = []

        edges1 = cv2.Canny(full_gray, 35, 110)
        kernel = np.ones((3, 3), np.uint8)
        closed = cv2.morphologyEx(edges1, cv2.MORPH_CLOSE, kernel, iterations=1)
        contours, _ = cv2.findContours(closed, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            if min_board_size <= w <= max_board_size and min_board_size <= h <= max_board_size:
                if 0.92 <= (w / float(h)) <= 1.08:
                    candidates.append((x, y, int((w + h) / 2)))

        best_bbox = None
        best_score = 20.0
        candidates.sort(key=lambda item: item[2], reverse=True)
        for (cx, cy, csize) in candidates[:40]:
            if cx < 0 or cy < 0 or cx + csize > w_scr or cy + csize > h_scr:
                continue
            patch = full_gray[cy:cy + csize, cx:cx + csize]
            score = cls._score_checkerboard_candidate(patch)
            if score > best_score:
                best_score = score
                best_bbox = {"left": int(cx), "top": int(cy), "width": int(csize), "height": int(csize)}
        return best_bbox


class ChessCoreApkBot:
    def __init__(self, stockfish_path, work_dir):
        self.stockfish_path = stockfish_path
        self.template_dir = os.path.join(work_dir, "templates")
        os.makedirs(self.template_dir, exist_ok=True)

        self.bbox = None
        self.my_color = "w"
        self.board = chess.Board()
        self.board_before_auto = None
        self.game_active = False
        self.move_history = []
        self.cp_loss_history = []
        self.last_opp_move = None
        self.pending_midgame_placement = None
        self.auto_click = True
        self.profile_idx = 0

        self.white_lum = 220.0
        self.black_lum = 45.0
        self.empty_std_thresh = 10.0
        self.templates = {}
        self.engine = None
        self._load_templates()
        self._init_engine()

    def _init_engine(self):
        if os.path.exists(self.stockfish_path):
            try:
                os.chmod(self.stockfish_path, 0o755)
                self.engine = chess.engine.SimpleEngine.popen_uci(self.stockfish_path)
                self.engine.configure({"Threads": 6, "Hash": 512, "Skill Level": 20})
            except Exception:
                self.engine = None

    def close_engine(self):
        if self.engine:
            try:
                self.engine.quit()
            except Exception:
                pass
            self.engine = None

    def _load_templates(self):
        meta_path = os.path.join(self.template_dir, "color_calib.json")
        if os.path.exists(meta_path):
            with open(meta_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.white_lum = data.get("white_lum", 220.0)
                self.black_lum = data.get("black_lum", 45.0)
                self.empty_std_thresh = data.get("empty_std_thresh", 10.0)
        self.templates = {}
        for piece in ["P", "R", "N", "B", "Q", "K"]:
            lst = []
            for idx in range(4):
                p = os.path.join(self.template_dir, f"{piece}_{idx}.png")
                if os.path.exists(p):
                    img = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
                    if img is not None:
                        lst.append(img)
            if lst:
                self.templates[piece] = lst

    def get_acpl(self):
        if not self.cp_loss_history:
            return 0.0
        return float(sum(self.cp_loss_history)) / len(self.cp_loss_history)

    def _sub_text(self):
        auto_s = "BẬT" if self.auto_click else "TẮT"
        return f"{STEALTH_PROFILES[self.profile_idx]['name']} | Auto: {auto_s} | ACPL: {self.get_acpl():.1f}"

    def cycle_profile(self):
        self.profile_idx = (self.profile_idx + 1) % 3
        return json.dumps({
            "status": f"Đã đổi độ thông minh: {STEALTH_PROFILES[self.profile_idx]['name']}",
            "color": "#CE93D8",
            "sub": self._sub_text()
        })

    def toggle_auto(self):
        self.auto_click = not self.auto_click
        st = "BẬT (Tự vuốt quân)" if self.auto_click else "TẮT (Chỉ vẽ mũi tên)"
        return json.dumps({
            "status": f"Auto-Touch: {st}",
            "color": "#4DD0E1",
            "sub": self._sub_text()
        })

    def reset_game(self):
        self.board = chess.Board()
        self.board_before_auto = None
        self.game_active = False
        self.move_history = []
        self.cp_loss_history = []
        self.last_opp_move = None
        self.pending_midgame_placement = None
        return json.dumps({
            "status": "🏁 Đã Reset ván cờ!",
            "color": "#FF8A65",
            "sub": self._sub_text()
        })

    def set_manual_bbox(self, left, top, size):
        self.bbox = {"left": int(left), "top": int(top), "width": int(size), "height": int(size)}

    def extract_square_features(self, square_bgr, need_edges=True):
        resized = cv2.resize(square_bgr, (64, 64), interpolation=cv2.INTER_AREA)
        gray_full = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
        patch_48 = gray_full[8:56, 8:56]
        blurred = cv2.GaussianBlur(patch_48, (3, 3), 0)
        edges = cv2.Canny(blurred, 40, 125)
        edges_out = cv2.dilate(edges, np.ones((2, 2), np.uint8), iterations=1) if need_edges else edges
        bg_corners = np.concatenate([
            gray_full[5:13, 5:15].flatten(),
            gray_full[5:13, 49:59].flatten(),
            gray_full[51:59, 5:13].flatten(),
            gray_full[51:59, 51:59].flatten(),
        ])
        bg_lum = float(np.median(bg_corners))
        body_region = gray_full[18:52, 16:48]
        diff = np.abs(body_region.astype(np.float32) - bg_lum)
        piece_pixels = body_region[diff > 16.0]
        piece_lum = float(np.median(piece_pixels)) if len(piece_pixels) >= 20 else float(np.median(gray_full[30:50, 20:44]))
        std_val = float(np.std(gray_full[14:50, 14:50]))
        return edges_out, std_val, piece_lum

    def is_square_empty(self, edges, std_val):
        edge_pixels = np.count_nonzero(edges[6:42, 6:42])
        if edge_pixels < 24:
            return True
        if std_val < self.empty_std_thresh and edge_pixels < 48:
            return True
        return False

    def calibrate_from_starting_board(self, board_img):
        h, w, _ = board_img.shape
        sq_h, sq_w = h / 8.0, w / 8.0
        def get_sq(r, c):
            return board_img[int(r * sq_h):int((r + 1) * sq_h), int(c * sq_w):int((c + 1) * sq_w)]

        mid_stds = [self.extract_square_features(get_sq(r, c))[1] for r in range(2, 6) for c in range(8)]
        outer_stds = [self.extract_square_features(get_sq(r, c))[1] for r in [0, 7] for c in range(8)]
        self.empty_std_thresh = (float(np.percentile(mid_stds, 80)) + float(np.percentile(outer_stds, 20))) / 2.0
        bot_lums = [self.extract_square_features(get_sq(r, c))[2] for r in [6, 7] for c in range(8)]
        top_lums = [self.extract_square_features(get_sq(r, c))[2] for r in [0, 1] for c in range(8)]
        avg_bot, avg_top = float(np.mean(bot_lums)), float(np.mean(top_lums))
        if avg_bot > avg_top:
            my_color = "w"
            self.white_lum, self.black_lum = avg_bot, avg_top
            col_map = {"R": [0, 7], "N": [1, 6], "B": [2, 5], "Q": [3], "K": [4]}
        else:
            my_color = "b"
            self.white_lum, self.black_lum = avg_top, avg_bot
            col_map = {"R": [0, 7], "N": [1, 6], "B": [2, 5], "K": [3], "Q": [4]}

        self.templates = {k: [] for k in ["P", "R", "N", "B", "Q", "K"]}
        for idx, c in enumerate([0, 1]):
            edges, _, _ = self.extract_square_features(get_sq(6, c))
            self.templates["P"].append(edges)
            cv2.imwrite(os.path.join(self.template_dir, f"P_{idx}.png"), edges)

        for piece_char, cols in col_map.items():
            sample_idx = 0
            for r_idx in [7, 0]:
                for c_idx in cols:
                    edges, _, _ = self.extract_square_features(get_sq(r_idx, c_idx))
                    if sample_idx < 4:
                        self.templates[piece_char].append(edges)
                        cv2.imwrite(os.path.join(self.template_dir, f"{piece_char}_{sample_idx}.png"), edges)
                        sample_idx += 1
        with open(os.path.join(self.template_dir, "color_calib.json"), "w", encoding="utf-8") as f:
            json.dump({"white_lum": self.white_lum, "black_lum": self.black_lum, "empty_std_thresh": self.empty_std_thresh}, f)
        return my_color

    def analyze_board_fast(self, board_img, my_color):
        h, w, _ = board_img.shape
        sq_h, sq_w = h / 8.0, w / 8.0
        occ_map, color_map = {}, {}
        for r in range(8):
            for c in range(8):
                sq_img = board_img[int(r * sq_h):int((r + 1) * sq_h), int(c * sq_w):int((c + 1) * sq_w)]
                edges, std_val, piece_lum = self.extract_square_features(sq_img, need_edges=False)
                file_idx, rank_idx = (c, 7 - r) if my_color == "w" else (7 - c, r)
                sq_idx = chess.square(file_idx, rank_idx)
                if self.is_square_empty(edges, std_val):
                    occ_map[sq_idx] = False
                    color_map[sq_idx] = None
                else:
                    occ_map[sq_idx] = True
                    is_white = abs(piece_lum - self.white_lum) < abs(piece_lum - self.black_lum)
                    color_map[sq_idx] = chess.WHITE if is_white else chess.BLACK
        return occ_map, color_map

    def analyze_board_full_templates(self, board_img, my_color):
        h, w, _ = board_img.shape
        sq_h, sq_w = h / 8.0, w / 8.0
        char_map = {}
        king_scores = {chess.WHITE: [], chess.BLACK: []}
        for r in range(8):
            for c in range(8):
                sq_img = board_img[int(r * sq_h):int((r + 1) * sq_h), int(c * sq_w):int((c + 1) * sq_w)]
                edges_48, std_val, piece_lum = self.extract_square_features(sq_img, need_edges=True)
                file_idx, rank_idx = (c, 7 - r) if my_color == "w" else (7 - c, r)
                sq_idx = chess.square(file_idx, rank_idx)
                if self.is_square_empty(edges_48, std_val):
                    char_map[sq_idx] = None
                else:
                    is_white = abs(piece_lum - self.white_lum) < abs(piece_lum - self.black_lum)
                    p_color = chess.WHITE if is_white else chess.BLACK
                    query_40 = edges_48[4:44, 4:44]
                    scores = {}
                    for piece_char, tmpl_list in self.templates.items():
                        if piece_char == "P" and rank_idx in [0, 7]:
                            continue
                        max_s = -1.0
                        for tmpl_48 in tmpl_list:
                            res = cv2.matchTemplate(tmpl_48, query_40, cv2.TM_CCOEFF_NORMED)
                            _, val, _, _ = cv2.minMaxLoc(res)
                            if val > max_s:
                                max_s = float(val)
                        scores[piece_char] = max_s
                    king_scores[p_color].append((scores.get("K", -1.0), sq_idx))
                    non_king = {k: v for k, v in scores.items() if k != "K"}
                    best_p = max(non_king, key=non_king.get) if non_king else "Q"
                    char_map[sq_idx] = best_p.upper() if is_white else best_p.lower()
        for p_color, cands in king_scores.items():
            if cands:
                cands.sort(key=lambda x: x[0], reverse=True)
                char_map[cands[0][1]] = "K" if p_color == chess.WHITE else "k"
        rows = []
        for rank_idx in range(7, -1, -1):
            empty_c = 0
            s = ""
            for file_idx in range(8):
                v = char_map.get(chess.square(file_idx, rank_idx))
                if v is None:
                    empty_c += 1
                else:
                    if empty_c > 0:
                        s += str(empty_c)
                        empty_c = 0
                    s += v
            if empty_c > 0:
                s += str(empty_c)
            rows.append(s)
        return "/".join(rows)

    def _square_to_xy(self, sq):
        f_idx = chess.square_file(sq)
        r_idx = chess.square_rank(sq)
        col, row = (f_idx, 7 - r_idx) if self.my_color == "w" else (7 - f_idx, r_idx)
        sq_w = self.bbox["width"] / 8.0
        sq_h = self.bbox["height"] / 8.0
        jx = max(-0.20, min(0.20, random.gauss(0.0, 0.08)))
        jy = max(-0.20, min(0.20, random.gauss(0.0, 0.08)))
        return self.bbox["left"] + (col + 0.5 + jx) * sq_w, self.bbox["top"] + (row + 0.5 + jy) * sq_h

    def _compute_engine_move_json(self):
        if self.engine is None:
            self._init_engine()
            if self.engine is None:
                return json.dumps({"status": "⚠️ Chưa tìm thấy libstockfish.so!", "color": "#FF5252"})

        mpv = 4 if self.profile_idx < 2 else 1
        infos = self.engine.analyse(self.board, chess.engine.Limit(time=0.18), multipv=mpv)
        if isinstance(infos, dict):
            infos = [infos]
        if not infos or not infos[0].get("pv"):
            return json.dumps({"status": "🏁 Ván cờ đã kết thúc!", "color": "#FFD54F"})

        best_move = infos[0]["pv"][0]
        depth = infos[0].get("depth", 18)
        profile = STEALTH_PROFILES[self.profile_idx]

        # Boltzmann Softmax ACPL
        if self.profile_idx < 2 and len(infos) >= 2 and len(self.move_history) >= 4:
            sc1 = infos[0].get("score")
            cp1 = sc1.pov(self.board.turn).score(mate_score=10000) if sc1 else None
            if cp1 is not None and abs(cp1) < 400 and not self.board.is_check():
                cands = []
                for idx, item in enumerate(infos[:4]):
                    pv = item.get("pv", [])
                    sc = item.get("score")
                    if pv and sc:
                        cpc = sc.pov(self.board.turn).score(mate_score=10000)
                        if cpc is not None:
                            loss = max(0, cp1 - cpc)
                            if idx == 0 or loss <= profile["max_cp_loss"]:
                                w = math.exp(-float(loss) / max(1.0, profile["temp"]))
                                cands.append((pv[0], loss, w))
                if len(cands) >= 2:
                    tot = sum(x[2] for x in cands)
                    r = random.uniform(0, tot)
                    up = 0.0
                    for mv, l, w in cands:
                        up += w
                        if r <= up:
                            best_move = mv
                            self.cp_loss_history.append(l)
                            break
                else:
                    self.cp_loss_history.append(0)
            else:
                self.cp_loss_history.append(0)
        else:
            self.cp_loss_history.append(0)

        moving_p = self.board.piece_at(best_move.from_square)
        p_type = moving_p.piece_type if moving_p else chess.PAWN
        meta = PIECE_INFO.get(p_type, PIECE_INFO[chess.PAWN])
        is_cap = self.board.is_capture(best_move)
        is_promo = best_move.promotion is not None

        x1, y1 = self._square_to_xy(best_move.from_square)
        x2, y2 = self._square_to_xy(best_move.to_square)
        dist = math.hypot(x2 - x1, y2 - y1)
        sq_sz = max(40.0, self.bbox["width"] / 8.0)

        cog_ms = 0 if self.profile_idx == 2 else int(max(65, min(360, random.lognormvariate(math.log(0.14), 0.30) * 1000)))
        drag_ms = int(max(95, min(210, (0.08 + 0.038 * math.log2(dist / sq_sz + 1.0)) * 1000)))
        use_tap = (self.profile_idx < 2) and (dist > sq_sz * 4.2) and (random.random() < 0.15)

        if self.auto_click:
            self.board_before_auto = self.board.copy()
            self.board.push(best_move)
            self.move_history.append(best_move.uci())

        f_name = chess.square_name(best_move.from_square).upper()
        t_name = chess.square_name(best_move.to_square).upper()
        arrow_s = "⚔️" if is_cap else "➔"

        return json.dumps({
            "status": f"🎯 {meta['name']}: {f_name} {arrow_s} {t_name} (D{depth})",
            "color": meta["color"],
            "sub": self._sub_text(),
            "has_move": True,
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
            "is_capture": is_cap,
            "is_promotion": is_promo,
            "auto_click": self.auto_click,
            "cog_delay_ms": cog_ms,
            "drag_ms": drag_ms,
            "use_tap_style": use_tap
        })

    def on_wb_pressed(self, wb_char):
        if self.pending_midgame_placement:
            fen = f"{self.pending_midgame_placement} {wb_char} - - 0 1"
            try:
                self.board = chess.Board(fen)
                self.game_active = True
                self.pending_midgame_placement = None
                if wb_char == self.my_color:
                    return self._compute_engine_move_json()
                return json.dumps({
                    "status": f"⏳ Đã khóa thế cờ! Đợi đối thủ đi rồi bấm [M].",
                    "color": "#00E676"
                })
            except Exception:
                return json.dumps({"status": "⚠️ FEN giữa ván chưa hợp lệ! Hãy bấm [N] đầu ván.", "color": "#FF5252"})
        self.my_color = wb_char
        return json.dumps({
            "status": f"Đã chọn phe: {'TRẮNG (W)' if wb_char == 'w' else 'ĐEN (B)'}",
            "color": "#FFD54F"
        })

    def process_screen(self, png_bytes, mode):
        arr = np.frombuffer(bytes(png_bytes), dtype=np.uint8)
        full_bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if full_bgr is None:
            return json.dumps({"status": "⚠️ Ảnh chụp màn hình rỗng!", "color": "#FF5252"})

        if self.bbox is None or mode == "n":
            detected = AutoBoardDetector.auto_detect_board(full_bgr)
            if detected:
                self.bbox = detected
            elif self.bbox is None:
                return json.dumps({
                    "status": "⚠️ Không tự thấy bàn cờ! Hãy bấm [O] dùng tay khoanh bàn cờ.",
                    "color": "#FFA726"
                })

        x, y, s = self.bbox["left"], self.bbox["top"], self.bbox["width"]
        board_img = full_bgr[y:y + s, x:x + s].copy()

        if mode in ("n", "c", "o_done"):
            self.my_color = self.calibrate_from_starting_board(board_img)
            self.board = chess.Board()
            self.game_active = True
            self.move_history = []
            self.cp_loss_history = []
            occ_map, color_map = self.analyze_board_fast(board_img, self.my_color)
            # Kiem tra neu cam quan Den va Trang da di nuoc dau
            for mv in self.board.legal_moves:
                if not occ_map[mv.from_square] and occ_map[mv.to_square]:
                    self.board.push(mv)
                    self.move_history.append(mv.uci())
                    break
            turn_c = "w" if self.board.turn == chess.WHITE else "b"
            if turn_c == self.my_color:
                return self._compute_engine_move_json()
            return json.dumps({
                "status": "⏳ Bạn cầm ĐEN — Đợi Trắng đi rồi bấm [M]",
                "color": "#29B6F6",
                "sub": self._sub_text()
            })

        # Mode 'm': Quet nuoc di tiep theo hoac giua van
        occ_map, color_map = self.analyze_board_fast(board_img, self.my_color)
        best_mv = None
        for mv in self.board.legal_moves:
            if not occ_map[mv.from_square] and occ_map[mv.to_square]:
                best_mv = mv
                break
        if best_mv is not None:
            self.board.push(best_mv)
            self.move_history.append(best_mv.uci())
            return self._compute_engine_move_json()

        # Neu la the co lon xon giua van -> Quet template va hoi nut W/B
        if not self.templates:
            return json.dumps({"status": "⚠️ Chưa có mẫu quân cờ! Hãy bấm [N] hoặc [C] ở đầu ván 1 lần.", "color": "#FFA726"})
        self.pending_midgame_placement = self.analyze_board_full_templates(board_img, self.my_color)
        return json.dumps({
            "status": "❓ Thế cờ giữa ván: Hãy bấm nút [W] hoặc [B] trên hộp để chọn lượt!",
            "color": "#FFD54F"
        })


def create_bot(stockfish_path, work_dir):
    return ChessCoreApkBot(stockfish_path, work_dir)
