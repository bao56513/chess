package com.v10.chesselite

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var statusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(48, 80, 48, 48)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val titleTv = TextView(this).apply {
            text = "CHESS AI V10.0 PRO MAX\n(Xiaomi 15 Pro - Snapdragon 8 Elite)"
            textSize = 18f
            setTextColor(Color.parseColor("#00E676"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 32)
        }
        root.addView(titleTv)

        statusTv = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(24, 24, 24, 32)
        }
        root.addView(statusTv)

        val btnOverlay = Button(this).apply {
            text = "1. Cap quyen Ve Hộp Box Nổi (Overlay)"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    Toast.makeText(this@MainActivity, "Da cap quyen Overlay!", Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(btnOverlay)

        val btnAccessibility = Button(this).apply {
            text = "2. Bat Dich vu Tro Nang (Chup & Vuot Quan)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(btnAccessibility)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        updateChecklist()
    }

    private fun updateChecklist() {
        val hasOverlay = Settings.canDrawOverlays(this)
        val sfFile = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
        val hasStockfish = sfFile.exists() && sfFile.canExecute()

        val sb = StringBuilder()
        sb.append("TRANG THAI KICH HOAT HE THONG:\n\n")
        sb.append(if (hasOverlay) "[OK] Quyen Cua so noi (Overlay)\n" else "[CHUA BAT] Quyen Cua so noi (Overlay)\n")
        sb.append(if (hasStockfish) "[OK] Engine libstockfish.so (ARMv8 DotProd)\n" else "[THIEU FILE] Chua dat libstockfish.so vao jniLibs/arm64-v8a\n")
        sb.append("\nSau khi bat muc (1) va (2), Hop Box V10 se tu dong hien len man hinh!")
        statusTv.text = sb.toString()
    }
}
