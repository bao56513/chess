package com.v10.chesselite

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.*
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class ChessAccessibilityService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val workerExecutor = Executors.newSingleThreadExecutor()

    private var floatingBoxView: View? = null
    private var arrowOverlayView: ArrowOverlayView? = null
    private var selectorOverlayView: RegionSelectorView? = null

    private lateinit var statusLabel: TextView
    private lateinit var subStatusLabel: TextView
    private var pyBot: PyObject? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }
        val py = Python.getInstance()
        val stockfishPath = File(applicationInfo.nativeLibraryDir, "libstockfish.so").absolutePath
        val workDir = filesDir.absolutePath
        pyBot = py.getModule("chess_core").callAttr("create_bot", stockfishPath, workDir)

        createArrowCanvasOverlay()
        createFloatingControlBox()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ================= 1. LOP VE MUI TEN NUOC DI XUYEN CAM UNG =================
    private fun createArrowCanvasOverlay() {
        arrowOverlayView = ArrowOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(arrowOverlayView, params)
    }

    // ================= 2. HOP BOX DIEU KHIEN NOI (KEO THA DUOC) =================
    private fun createFloatingControlBox() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val boxLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E6121212"))
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        // Thanh tieu de keo tha hop Box
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#263238"))
            setPadding(dp(6), dp(4), dp(6), dp(4))
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleTv = TextView(this).apply {
            text = "⚡ V10 8-ELITE (Keo de di chuyen)"
            setTextColor(Color.parseColor("#00E676"))
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        headerLayout.addView(titleTv)

        val closeBtn = TextView(this).apply {
            text = " ✕ "
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#C62828"))
            textSize = 11f
            setOnClickListener {
                pyBot?.callAttr("close_engine")
                disableSelf()
            }
        }
        headerLayout.addView(closeBtn)
        boxLayout.addView(headerLayout)

        // Nhan hien thi nuoc di va trang thai
        statusLabel = TextView(this).apply {
            text = "San sang: Bam [N] van moi, [M] giua van, [O] khoanh ban"
            setTextColor(Color.WHITE)
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(4), dp(4), dp(4), dp(2))
        }
        boxLayout.addView(statusLabel)

        subStatusLabel = TextView(this).apply {
            text = "🛡️ ULTRA STEALTH (~86%) | Auto: BAT | ACPL: 0.0"
            setTextColor(Color.parseColor("#B0BEC5"))
            textSize = 10f
            setPadding(dp(4), 0, dp(4), dp(4))
        }
        boxLayout.addView(subStatusLabel)

        fun makeBtn(label: String, bgHex: String, fgHex: String = "#FFFFFF", onClick: () -> Unit): Button {
            return Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(Color.parseColor(fgHex))
                setBackgroundColor(Color.parseColor(bgHex))
                minHeight = dp(34)
                minimumHeight = dp(34)
                setPadding(dp(2), dp(2), dp(2), dp(2))
                layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
                setOnClickListener { onClick() }
            }
        }

        // Hang nut 1: N, M, O, W, B
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(makeBtn("N", "#2E7D32") { triggerScan(mode = "n") })
        row1.addView(makeBtn("M", "#1565C0") { triggerScan(mode = "m") })
        row1.addView(makeBtn("O", "#EF6C00") { openManualRegionSelector() })
        row1.addView(makeBtn("W", "#EEEEEE", "#000000") { selectTurnOrSide("w") })
        row1.addView(makeBtn("B", "#37474F") { selectTurnOrSide("b") })
        boxLayout.addView(row1)

        // Hang nut 2: P (Do thong minh), A (Auto Touch), C (Hoc mau), ESC (Reset)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(makeBtn("P (Độ khôn)", "#6A1B9A") {
            val res = pyBot?.callAttr("cycle_profile")?.toString() ?: ""
            updateUiFromJson(res)
        })
        row2.addView(makeBtn("A (Auto)", "#00838F") {
            val res = pyBot?.callAttr("toggle_auto")?.toString() ?: ""
            updateUiFromJson(res)
        })
        row2.addView(makeBtn("C (Mẫu)", "#455A64") { triggerScan(mode = "c") })
        row2.addView(makeBtn("ESC", "#AD1457") {
            arrowOverlayView?.clearArrow()
            val res = pyBot?.callAttr("reset_game")?.toString() ?: ""
            updateUiFromJson(res)
        })
        boxLayout.addView(row2)

        val params = WindowManager.LayoutParams(
            dp(330),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 120
        }

        // Xu ly keo di chuyen hop Box tren man hinh
        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        headerLayout.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x
                    initY = params.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initX + (ev.rawX - touchX).toInt()
                    params.y = initY + (ev.rawY - touchY).toInt()
                    windowManager.updateViewLayout(boxLayout, params)
                    true
                }
                else -> false
            }
        }

        floatingBoxView = boxLayout
        windowManager.addView(boxLayout, params)
    }

    // ================= 3. KHOANH VUNG BAN CO BANG TAY (NUT O) =================
    private fun openManualRegionSelector() {
        if (selectorOverlayView != null) return
        arrowOverlayView?.clearArrow()
        statusLabel.text = "➕ Dung tay keo tu goc nay sang goc kia cua ban co..."

        selectorOverlayView = RegionSelectorView(this) { rect ->
            selectorOverlayView?.let { windowManager.removeView(it) }
            selectorOverlayView = null

            if (rect.width() > 100 && rect.height() > 100) {
                val size = (rect.width() + rect.height()) / 2
                pyBot?.callAttr("set_manual_bbox", rect.left, rect.top, size)
                statusLabel.text = "✅ Da khoanh ban co (${size}x${size}). Dang quet..."
                triggerScan(mode = "o_done")
            } else {
                statusLabel.text = "⚠️ Vung khoanh qua nho! Bam [O] de khoanh lai."
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(selectorOverlayView, params)
    }

    // ================= 4. CHUP MAN HINH & GOI PYTHON + STOCKFISH =================
    private fun selectTurnOrSide(wb: String) {
        statusLabel.text = "⚡ Dang tinh nuoc cho luot ${wb.uppercase()}..."
        workerExecutor.execute {
            val res = pyBot?.callAttr("on_wb_pressed", wb)?.toString() ?: return@execute
            mainHandler.post { handleEngineDecisionJson(res) }
        }
    }

    private fun triggerScan(mode: String) {
        statusLabel.text = "📸 Dang chup va phan tich ban co ($mode)..."
        arrowOverlayView?.clearArrow()
        floatingBoxView?.alpha = 0.0f // Tam an Hop Box 50ms khi chup de khong che ban co

        mainHandler.postDelayed({
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    workerExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshotResult: ScreenshotResult) {
                            mainHandler.post { floatingBoxView?.alpha = 1.0f }
                            val hb = screenshotResult.hardwareBuffer
                            val colorSpace = screenshotResult.colorSpace
                            val hwBitmap = Bitmap.wrapHardwareBuffer(hb, colorSpace)
                            hb.close()
                            if (hwBitmap != null) {
                                val softBitmap = hwBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                hwBitmap.recycle()
                                val stream = ByteArrayOutputStream()
                                softBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                                softBitmap.recycle()
                                val pngBytes = stream.toByteArray()

                                val res = pyBot?.callAttr("process_screen", pngBytes, mode)?.toString() ?: ""
                                mainHandler.post { handleEngineDecisionJson(res) }
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            mainHandler.post {
                                floatingBoxView?.alpha = 1.0f
                                statusLabel.text = "⚠️ Loi chup man hinh ($errorCode). Hay doi 1s roi bam lai!"
                            }
                        }
                    }
                )
            }
        }, 55)
    }

    private fun updateUiFromJson(jsonStr: String) {
        if (jsonStr.isEmpty()) return
        val obj = JSONObject(jsonStr)
        statusLabel.text = obj.optString("status", statusLabel.text.toString())
        val colorHex = obj.optString("color", "#FFFFFF")
        statusLabel.setTextColor(Color.parseColor(colorHex))
        if (obj.has("sub")) {
            subStatusLabel.text = obj.optString("sub")
        }
    }

    private fun handleEngineDecisionJson(jsonStr: String) {
        if (jsonStr.isEmpty()) return
        val obj = JSONObject(jsonStr)
        updateUiFromJson(jsonStr)

        if (obj.optBoolean("has_move", false)) {
            val x1 = obj.getDouble("x1").toFloat()
            val y1 = obj.getDouble("y1").toFloat()
            val x2 = obj.getDouble("x2").toFloat()
            val y2 = obj.getDouble("y2").toFloat()
            val colorHex = obj.optString("color", "#00E676")
            val isCapture = obj.optBoolean("is_capture", false)
            val autoClick = obj.optBoolean("auto_click", true)
            val cogDelayMs = obj.optLong("cog_delay_ms", 120L)
            val dragDurationMs = obj.optLong("drag_ms", 145L)
            val useTapStyle = obj.optBoolean("use_tap_style", false)
            val isPromo = obj.optBoolean("is_promotion", false)

            arrowOverlayView?.setArrow(x1, y1, x2, y2, Color.parseColor(colorHex), isCapture)

            if (autoClick) {
                mainHandler.postDelayed({
                    performBioCurvedTouch(x1, y1, x2, y2, dragDurationMs, useTapStyle, isPromo)
                }, cogDelayMs)
            }
        }
    }

    // ================= 5. VUOT CONG SINH TRAC HOC V10 (CURVED BEZIER GESTURE) =================
    private fun performBioCurvedTouch(
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        durationMs: Long,
        useTapStyle: Boolean,
        isPromotion: Boolean
    ) {
        if (useTapStyle) {
            // 15% nuoc di xa: Cham chon quan -> Nghi Fitts -> Cham o dich
            dispatchSingleTap(x1, y1) {
                mainHandler.postDelayed({
                    dispatchSingleTap(x2, y2) {
                        if (isPromotion) {
                            mainHandler.postDelayed({ dispatchSingleTap(x2, y2) {} }, 110L)
                        }
                    }
                }, Random.nextLong(95L, 185L))
            }
            return
        }

        // 85% nuoc di: Keo cong Bezier (cam giu nhac quan va uon cong nhu tay nguoi that)
        val dist = hypot((x2 - x1).toDouble(), (y2 - y1).toDouble()).toFloat()
        val nx = -(y2 - y1) / max(1f, dist)
        val ny = (x2 - x1) / max(1f, dist)
        val curveDir = if (Random.nextBoolean()) 1f else -1f
        val arcOffset = min(42f, max(12f, dist * 0.14f)) * curveDir
        val ctrlX = (x1 + x2) / 2f + nx * arcOffset
        val ctrlY = (y1 + y2) / 2f + ny * arcOffset

        val path = Path().apply {
            moveTo(x1, y1)
            quadTo(ctrlX, ctrlY, x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, max(85L, durationMs))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (isPromotion) {
                    mainHandler.postDelayed({ dispatchSingleTap(x2, y2) {} }, 110L)
                }
            }
        }, null)
    }

    private fun dispatchSingleTap(x: Float, y: Float, onDone: () -> Unit) {
        val p = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(p, 0L, Random.nextLong(22L, 42L))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onDone()
            }
        }, null)
    }

    // ================= VIEW VE MUI TEN GOI Y =================
    inner class ArrowOverlayView(context: Context) : View(context) {
        private var hasArrow = false
        private var sx = 0f
        private var sy = 0f
        private var ex = 0f
        private var ey = 0f
        private var isCap = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
            pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
        }

        fun setArrow(x1: Float, y1: Float, x2: Float, y2: Float, color: Int, capture: Boolean) {
            sx = x1; sy = y1; ex = x2; ey = y2
            paint.color = color
            paint.alpha = 190
            isCap = capture
            hasArrow = true
            invalidate()
        }

        fun clearArrow() {
            hasArrow = false
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (!hasArrow) return
            canvas.drawCircle(sx, sy, 28f, paint)
            val path = Path().apply {
                moveTo(sx, sy)
                val mx = (sx + ex) / 2f - (ey - sy) * 0.12f
                val my = (sy + ey) / 2f + (ex - sx) * 0.12f
                quadTo(mx, my, ex, ey)
            }
            canvas.drawPath(path, paint)
            canvas.drawCircle(ex, ey, if (isCap) 34f else 16f, paint)
        }
    }

    // ================= VIEW KHOANH VUNG BAN CO BANG NGON TAY (NUT O) =================
    inner class RegionSelectorView(
        context: Context,
        val onSelected: (Rect) -> Unit
    ) : View(context) {
        private var startX = 0f
        private var startY = 0f
        private var curX = 0f
        private var curY = 0f
        private var dragging = false

        private val bgPaint = Paint().apply { color = Color.parseColor("#55000000") }
        private val rectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00E676")
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    startY = event.rawY
                    curX = startX
                    curY = startY
                    dragging = true
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    curX = event.rawX
                    curY = event.rawY
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    dragging = false
                    val left = min(startX, curX).toInt()
                    val top = min(startY, curY).toInt()
                    val right = max(startX, curX).toInt()
                    val bottom = max(startY, curY).toInt()
                    onSelected(Rect(left, top, right, bottom))
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            if (dragging) {
                canvas.drawRect(
                    min(startX, curX),
                    min(startY, curY),
                    max(startX, curX),
                    max(startY, curY),
                    rectPaint
                )
            }
        }
    }
}
