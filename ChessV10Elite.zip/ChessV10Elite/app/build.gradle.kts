plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.v10.chesselite"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.v10.chesselite"
        minSdk = 30 // Android 11+ ho tro AccessibilityService.takeScreenshot() goc
        targetSdk = 34
        versionCode = 10
        versionName = "10.0-8Elite"

        ndk {
            // Toi uu rieng cho Xiaomi 15 Pro (Snapdragon 8 Elite - ARM64)
            abiFilters += listOf("arm64-v8a")
        }

        python {
            version = "3.10"
            pip {
                install("numpy")
                install("opencv-python-headless")
                install("chess")
            }
        }
    }

    packaging {
        jniLibs {
            // Bat buoc de Android giai nen libstockfish.so ra thu muc co quyen thuc thi (exec)
            useLegacyPackaging = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
